# OpenCV 학습용 테스팅 보드 - 구현 이력 문서

## 📋 프로젝트 개요

**프로젝트명**: OpenCV 학습용 테스팅 보드  
**목적**: 학생들이 OpenCV 내장 함수를 카테고리별로 학습하고, 각 함수의 인자들이 어떤 역할을 하는지 실시간으로 테스트할 수 있는 교육용 도구  
**완성일**: 2026년 2월 13일  
**기술 스택**: React, TypeScript, OpenCV.js, Tailwind CSS, shadcn/ui

---

## 🎯 핵심 기능

### 1. 3단계 워크플로우
- **입력 단계**: 이미지/동영상 업로드 (최대 2개의 입력 이미지 지원)
- **처리 단계**: 함수 선택 및 파라미터 조정
- **출력 단계**: 실시간 결과 확인 및 다운로드

### 2. 교육용 기능
- OpenCV 공식 문서 링크 제공
- 정확한 함수 문법 표시
- 상세한 파라미터 설명
- 처리 시간 측정 및 표시
- 실시간 미리보기

### 3. 사용자 인터페이스
- 직관적인 3단 레이아웃 (입력 | 제어 | 출력)
- 카테고리별 함수 그룹핑
- 동적 파라미터 입력 UI
- 반응형 디자인

---

## 📁 프로젝트 구조

```
/src/app/
├── App.tsx                          # 메인 애플리케이션
├── components/
│   ├── ImageUploader.tsx            # 이미지 업로드 컴포넌트
│   ├── FunctionSelector.tsx         # 함수 선택 컴포넌트
│   ├── ParameterInput.tsx           # 파라미터 입력 컴포넌트
│   ├── OutputPanel.tsx              # 출력 패널 컴포넌트
│   ├── UsagePanel.tsx               # 사용법 표시 컴포넌트
│   └── ui/                          # shadcn/ui 컴포넌트
├── data/
│   └── opencv-functions.ts          # 170개 OpenCV 함수 정의
└── utils/
    └── opencv-processor.ts          # OpenCV 처리 로직

/src/styles/
├── fonts.css                        # 폰트 설정
├── index.css                        # 전역 스타일
├── tailwind.css                     # Tailwind 설정
└── theme.css                        # 테마 변수
```

---

## 🔧 주요 컴포넌트 상세

### 1. App.tsx (메인 애플리케이션)
- **역할**: 전체 애플리케이션 상태 관리 및 워크플로우 조율
- **주요 기능**:
  - OpenCV.js 라이브러리 로딩
  - 이미지 입력 관리 (최대 2개)
  - 함수 선택 및 파라미터 관리
  - 이미지 처리 실행 및 결과 표시
  - 처리 시간 측정

### 2. ImageUploader.tsx
- **역할**: 이미지 파일 업로드 및 Canvas 변환
- **주요 기능**:
  - 드래그 앤 드롭 지원
  - 파일 선택 지원
  - 이미지 미리보기
  - Canvas로 변환 후 부모 컴포넌트에 전달
  - 초기화 기능

### 3. FunctionSelector.tsx
- **역할**: 카테고리별 OpenCV 함수 선택 인터페이스
- **주요 기능**:
  - 21개 카테고리 표시
  - 각 카테고리별 함수 목록
  - 검색 기능
  - 함수 설명 표시
  - 선택된 함수 하이라이트

### 4. ParameterInput.tsx
- **역할**: 선택된 함수의 파라미터 동적 입력 UI
- **주요 기능**:
  - 다양한 입력 타입 지원:
    - number: 숫자 입력
    - slider: 슬라이더
    - select: 드롭다운
    - color: 색상 선택
    - size: 커널 크기 선택
  - 파라미터 설명 표시
  - 기본값 설정
  - 유효성 검사

### 5. OutputPanel.tsx
- **역할**: 처리 결과 표시 및 다운로드
- **주요 기능**:
  - 처리된 이미지 표시
  - 이미지 다운로드
  - 처리 정보 표시
  - 처리 시간 표시
  - 줌/확대 기능

### 6. UsagePanel.tsx
- **역할**: 선택된 함수의 사용법 및 문서 표시
- **주요 기능**:
  - 함수 설명 표시
  - 정확한 Python/C++ 문법 표시
  - 파라미터 상세 설명
  - OpenCV 공식 문서 링크
  - 코드 예제

---

## 📊 구현된 OpenCV 함수 (22개 카테고리, 178개 함수)

### 1. 색상 변환 (Color) - 14개 함수
- `cvtColor_GRAY`: 그레이스케일 변환
- `cvtColor_HSV`: HSV 색공간 변환
- `cvtColor_LAB`: LAB 색공간 변환
- `cvtColor_YCrCb`: YCrCb 색공간 변환
- `cvtColor_XYZ`: XYZ 색공간 변환
- `cvtColor_HLS`: HLS 색공간 변환
- `cvtColor_Luv`: Luv 색공간 변환
- `cvtColor_YUV`: YUV 색공간 변환
- `cvtColor_BGR2RGB`: BGR ↔ RGB 변환
- `cvtColor_BGR2BGRA`: 알파 채널 추가
- `cvtColor_BGRA2BGR`: 알파 채널 제거
- `split`: 채널 분리
- `merge`: 채널 병합
- `mixChannels`: 채널 혼합

### 2. ColorMaps - 22개 함수
- `COLORMAP_AUTUMN`, `COLORMAP_BONE`, `COLORMAP_JET`, `COLORMAP_WINTER`, 
- `COLORMAP_RAINBOW`, `COLORMAP_OCEAN`, `COLORMAP_SUMMER`, `COLORMAP_SPRING`,
- `COLORMAP_COOL`, `COLORMAP_HSV`, `COLORMAP_PINK`, `COLORMAP_HOT`,
- `COLORMAP_PARULA`, `COLORMAP_MAGMA`, `COLORMAP_INFERNO`, `COLORMAP_PLASMA`,
- `COLORMAP_VIRIDIS`, `COLORMAP_CIVIDIS`, `COLORMAP_TWILIGHT`, `COLORMAP_TWILIGHT_SHIFTED`,
- `COLORMAP_TURBO`, `COLORMAP_DEEPGREEN`

### 3. 필터링 (Filter) - 11개 함수
- `blur`: 평균 블러
- `GaussianBlur`: 가우시안 블러
- `medianBlur`: 중간값 블러
- `bilateralFilter`: 양방향 필터
- `boxFilter`: 박스 필터
- `sqrBoxFilter`: 제곱 박스 필터
- `filter2D`: 사용자 정의 커널 필터
- `sepFilter2D`: 분리 가능한 필터
- `Laplacian`: 라플라시안 필터
- `Sobel`: Sobel 필터
- `Scharr`: Scharr 필터

### 4. 형태학 연산 (Morphology) - 10개 함수
- `erode`: 침식
- `dilate`: 팽창
- `morphologyEx_OPEN`: 열기 연산
- `morphologyEx_CLOSE`: 닫기 연산
- `morphologyEx_GRADIENT`: 형태학적 그래디언트
- `morphologyEx_TOPHAT`: 탑햇 변환
- `morphologyEx_BLACKHAT`: 블랙햇 변환
- `morphologyEx_HITMISS`: 힌트미스 변환
- `getStructuringElement`: 구조 요소 생성
- `morphologyEx`: 일반 형태학 연산

### 5. 임계값 처리 (Threshold) - 9개 함수
- `threshold_BINARY`: 이진 임계값
- `threshold_BINARY_INV`: 역 이진 임계값
- `threshold_TRUNC`: 잘라내기 임계값
- `threshold_TOZERO`: 0으로 설정
- `threshold_TOZERO_INV`: 역 0으로 설정
- `adaptiveThreshold_MEAN`: 평균 적응형 임계값
- `adaptiveThreshold_GAUSSIAN`: 가우시안 적응형 임계값
- `threshold_OTSU`: Otsu 임계값
- `threshold_TRIANGLE`: Triangle 임계값

### 6. 엣지 검출 (Edge) - 4개 함수
- `Canny`: Canny 엣지 검출
- `Sobel_edge`: Sobel 엣지 검출
- `Scharr_edge`: Scharr 엣지 검출
- `Laplacian_edge`: Laplacian 엣지 검출

### 7. 윤곽선 검출 (Contour) - 8개 함수
- `findContours`: 윤곽선 찾기
- `drawContours`: 윤곽선 그리기
- `contourArea`: 윤곽선 면적
- `arcLength`: 윤곽선 둘레
- `approxPolyDP`: 윤곽선 근사화
- `convexHull`: 볼록 껍질
- `boundingRect`: 경계 사각형
- `minAreaRect`: 최소 면적 회전 사각형

### 8. 형상 분석 (Shape) - 7개 함수
- `moments`: 모멘트 계산
- `HuMoments`: Hu 모멘트
- `matchShapes`: 형상 매칭
- `fitEllipse`: 타원 피팅
- `fitLine`: 직선 피팅
- `minEnclosingCircle`: 최소 포함 원
- `minEnclosingTriangle`: 최소 포함 삼각형

### 9. 특징 검출 (Feature) - 9개 함수
- `goodFeaturesToTrack`: 코너 검출
- `cornerHarris`: Harris 코너 검출
- `cornerMinEigenVal`: 최소 고유값 코너 검출
- `cornerEigenValsAndVecs`: 고유값과 벡터
- `preCornerDetect`: 코너 사전 검출
- `cornerSubPix`: 서브픽셀 코너
- `HoughLines`: Hough 직선 검출
- `HoughLinesP`: 확률적 Hough 직선 검출
- `HoughCircles`: Hough 원 검출

### 10. 히스토그램 (Histogram) - 6개 함수
- `calcHist`: 히스토그램 계산
- `equalizeHist`: 히스토그램 평활화
- `calcBackProject`: 역투영
- `compareHist_CORREL`: 히스토그램 상관관계 비교
- `compareHist_CHISQR`: 카이제곱 비교
- `compareHist_BHATTACHARYYA`: Bhattacharyya 거리

### 11. 기하학 변환 (Transform) - 12개 함수
- `resize_INTER_LINEAR`: 선형 보간 리사이즈
- `resize_INTER_NEAREST`: 최근접 이웃 리사이즈
- `resize_INTER_CUBIC`: 3차 보간 리사이즈
- `resize_INTER_LANCZOS4`: Lanczos 보간 리사이즈
- `flip_HORIZONTAL`: 수평 뒤집기
- `flip_VERTICAL`: 수직 뒤집기
- `flip_BOTH`: 양방향 뒤집기
- `rotate_90`: 90도 회전
- `rotate_180`: 180도 회전
- `rotate_270`: 270도 회전
- `warpAffine`: 아핀 변환
- `warpPerspective`: 원근 변환

### 12. 이미지 피라미드 (Pyramid) - 4개 함수
- `pyrDown`: 이미지 축소
- `pyrUp`: 이미지 확대
- `buildPyramid`: 피라미드 생성
- `pyrMeanShiftFiltering`: Mean Shift 필터링

### 13. 기본 연산 (Basic) - 7개 함수
- `add`: 덧셈
- `subtract`: 뺄셈
- `multiply`: 곱셈
- `divide`: 나눗셈
- `addWeighted`: 가중치 합
- `absdiff`: 절대 차이
- `bitwise_not`: 비트 NOT

### 14. 산술 연산 (Arithmetic) - 9개 함수
- `bitwise_and`: 비트 AND
- `bitwise_or`: 비트 OR
- `bitwise_xor`: 비트 XOR
- `min`: 최솟값
- `max`: 최댓값
- `pow`: 거듭제곱
- `sqrt`: 제곱근
- `exp`: 지수
- `log`: 로그

### 15. 비교 연산 (Comparison) - 6개 함수
- `compare_GT`: 크다 (>)
- `compare_GE`: 크거나 같다 (>=)
- `compare_LT`: 작다 (<)
- `compare_LE`: 작거나 같다 (<=)
- `compare_EQ`: 같다 (==)
- `compare_NE`: 다르다 (!=)

### 16. 통계 연산 (Statistical) - 6개 함수
- `mean`: 평균
- `meanStdDev`: 평균과 표준편차
- `minMaxLoc`: 최솟값/최댓값 위치
- `countNonZero`: 0이 아닌 픽셀 개수
- `reduce_SUM`: 행/열 합계
- `reduce_AVG`: 행/열 평균

### 17. 행렬 연산 (Matrix) - 8개 함수
- `transpose`: 전치
- `invert`: 역행렬
- `determinant`: 행렬식
- `trace`: 대각합
- `normalize_MINMAX`: 정규화
- `normalize_L2`: L2 정규화
- `gemm`: 일반 행렬 곱셈
- `transform`: 행렬 변환

### 18. 고급 필터 (Advanced Filter) - 8개 함수
- `fastNlMeansDenoising`: 노이즈 제거
- `fastNlMeansDenoisingColored`: 컬러 노이즈 제거
- `decolor`: 색상 제거
- `edgePreservingFilter`: 엣지 보존 필터
- `detailEnhance`: 디테일 강화
- `pencilSketch`: 연필 스케치 효과
- `stylization`: 스타일화
- `illuminationChange`: 조명 변화

### 19. 미분 연산 (Derivative) - 3개 함수
- `Sobel_derivative`: Sobel 미분
- `Scharr_derivative`: Scharr 미분
- `spatialGradient`: 공간 그래디언트

### 20. 그리기 (Drawing) - 7개 함수
- `line`: 직선 그리기
- `rectangle`: 사각형 그리기
- `circle`: 원 그리기
- `ellipse`: 타원 그리기
- `polylines`: 다각형 선 그리기
- `fillPoly`: 채워진 다각형
- `putText`: 텍스트 그리기

### 21. 각종 이미지변환 (Misc) - 10개 함수
- `integral`: 적분 이미지
- `Sobel`: Sobel 연산자
- `convertScaleAbs`: 스케일 변환
- `magnitude`: 크기 계산
- `phase`: 위상 계산
- `cartToPolar`: 직교→극좌표 변환
- `polarToCart`: 극→직교좌표 변환
- `distanceTransform`: 거리 변환
- `floodFill`: 영역 채우기
- `grabCut`: GrabCut 분할

### 22. 모션 분석 및 객체 추적 (Motion) - 8개 함수
- `accumulate`: 이미지 누적 (배경 모델링)
- `accumulateSquare`: 제곱 이미지 누적 (분산 계산)
- `accumulateProduct`: 곱 이미지 누적 (공분산 계산)
- `accumulateWeighted`: 가중치 이미지 누적 (배경 차분)
- `createHanningWindow`: 한닝 윈도우 생성
- `phaseCorrelate`: 위상 상관 (이동 벡터 계산)
- `meanShift`: Mean Shift 객체 추적
- `CamShift`: Continuously Adaptive Mean Shift 추적

---

## 🔨 구현 세부 사항

### 데이터 구조 (opencv-functions.ts)

```typescript
export interface FunctionParameter {
  name: string;                          // 파라미터 이름
  type: 'number' | 'select' | 'slider' | 'color' | 'size';
  defaultValue: any;                     // 기본값
  min?: number;                          // 최솟값 (number/slider)
  max?: number;                          // 최댓값 (number/slider)
  step?: number;                         // 증감 단위
  options?: { label: string; value: any }[]; // 선택 옵션 (select)
  description: string;                   // 파라미터 설명
}

export interface OpenCVFunction {
  id: string;                           // 함수 고유 ID
  name: string;                         // 함수 표시 이름
  category: string;                     // 카테고리 ID
  description: string;                  // 함수 설명
  parameters: FunctionParameter[];      // 파라미터 배열
  requiresGrayscale?: boolean;          // 그레이스케일 필수 여부
  inputCount?: number;                  // 필요한 입력 이미지 개수
  syntax: string;                       // 함수 문법 (Python)
  documentation: string;                // OpenCV 공식 문서 URL
}
```

### OpenCV 처리 로직 (opencv-processor.ts)

- **OpenCV.js 로딩**: CDN에서 라이브러리 동적 로드
- **이미지 처리 파이프라인**:
  1. Canvas에서 cv.Mat으로 변환
  2. 필요시 그레이스케일 변환
  3. 선택된 함수 실행
  4. 결과를 Canvas로 변환
  5. DataURL로 반환
- **메모리 관리**: cv.Mat 객체 자동 해제
- **에러 처리**: 상세한 에러 메시지 제공

### 주요 처리 함수 예시

각 OpenCV 함수는 switch-case 문으로 구현:

```typescript
switch (functionId) {
  case 'blur': {
    const ksize = new cv.Size(params.ksize, params.ksize);
    cv.blur(src, dst, ksize);
    break;
  }
  case 'GaussianBlur': {
    const ksize = new cv.Size(params.ksize, params.ksize);
    cv.GaussianBlur(src, dst, ksize, params.sigmaX);
    break;
  }
  // ... 170개 함수 구현
}
```

---

## 🐛 해결된 주요 이슈

### 1. 중복 case문 제거 (2026-02-13)
**문제**: opencv-processor.ts에서 동일한 함수 ID가 여러 번 정의되어 빌드 오류 발생

**해결**:
- `cvtColor_GRAY`, `cvtColor_HSV` 등 14개 색상 변환 함수의 중복 case문 제거
- `COLORMAP_AUTUMN` ~ `COLORMAP_DEEPGREEN` 등 22개 ColorMap 함수의 중복 case문 제거
- 각 함수당 하나의 case문만 유지

### 2. 중복 함수 정의 제거 (2026-02-13)
**문제**: opencv-functions.ts에서 동일한 함수가 여러 번 정의되어 React key 중복 경고 발생

**해결**:
- 색상 변환 카테고리의 중복 함수 정의 제거
- ColorMaps 카테고리의 중복 함수 정의 제거
- 각 함수는 하나의 정의만 유지

### 3. TypeScript 타입 안정성
**해결책**:
- 모든 컴포넌트에 명확한 타입 정의
- Props 인터페이스 정의
- OpenCV 함수 반환값 타입 체크

### 4. 메모리 관리
**해결책**:
- cv.Mat 객체 사용 후 즉시 delete()
- try-finally 블록으로 메모리 누수 방지
- 대용량 이미지 처리 최적화

---

## 📚 사용된 라이브러리 및 도구

### 핵심 라이브러리
- **React 18**: UI 프레임워크
- **TypeScript**: 타입 안정성
- **OpenCV.js 4.10.0**: 이미지 처리 엔진
- **Tailwind CSS v4**: 스타일링
- **Vite**: 빌드 도구

### UI 컴포넌트
- **shadcn/ui**: 재사용 가능한 UI 컴포넌트
  - Button, Card, Select, Input, Slider
  - Accordion, Tabs, Alert
  - ScrollArea, Separator
- **lucide-react**: 아이콘 라이브러리

### 개발 도구
- **ESLint**: 코드 품질
- **PostCSS**: CSS 처리
- **pnpm**: 패키지 관리

---

## 🎓 교육적 가치

### 1. 실습 중심 학습
- 이론이 아닌 실제 결과를 즉시 확인
- 파라미터 변경에 따른 결과 변화 체험
- 다양한 함수 조합 실험 가능

### 2. 체계적인 학습 경로
- 21개 카테고리로 구조화된 학습
- 기초부터 고급까지 단계적 학습
- 관련 함수들의 그룹핑

### 3. 참조 자료 제공
- 정확한 함수 문법 표시
- 파라미터 상세 설명
- 공식 문서 바로가기

### 4. 실시간 피드백
- 처리 시간 측정
- 에러 메시지 표시
- 시각적 결과 확인

---

## 🚀 향후 확장 가능성

### 기능 확장
1. **동영상 처리**: 실시간 비디오 스트림 처리
2. **배치 처리**: 여러 이미지 일괄 처리
3. **함수 체이닝**: 여러 함수를 순차적으로 적용
4. **프리셋 저장**: 자주 사용하는 설정 저장
5. **비교 모드**: 처리 전/후 나란히 비교

### 교육 콘텐츠
1. **튜토리얼 모드**: 단계별 가이드
2. **퀴즈/실습**: 학습 평가
3. **예제 갤러리**: 다양한 활용 사례
4. **코드 내보내기**: Python/C++ 코드 생성

### 성능 최적화
1. **Web Worker**: 별도 스레드에서 처리
2. **WebAssembly**: 네이티브 수준 성능
3. **캐싱**: 처리 결과 캐싱
4. **지연 로딩**: 필요한 함수만 로드

---

## 📝 개발 과정 타임라인

### Phase 1: 기획 및 설계
- 요구사항 분석
- UI/UX 디자인
- 데이터 구조 설계
- 기술 스택 선정

### Phase 2: 기본 구조 구축
- 프로젝트 초기화 (React + TypeScript + Vite)
- Tailwind CSS 및 shadcn/ui 설정
- 기본 레이아웃 구현
- OpenCV.js 통합

### Phase 3: 핵심 기능 구현
- 이미지 업로드 기능
- 함수 선택 인터페이스
- 파라미터 입력 UI
- 이미지 처리 파이프라인

### Phase 4: OpenCV 함수 구현
- 22개 카테고리 정의
- 178개 함수 구현
  - 색상 변환 (14개)
  - ColorMaps (22개)
  - 필터링 (11개)
  - 형태학 연산 (10개)
  - 임계값 처리 (9개)
  - 엣지 검출 (4개)
  - 윤곽선 검출 (8개)
  - 형상 분석 (7개)
  - 특징 검출 (9개)
  - 히스토그램 (6개)
  - 기하학 변환 (12개)
  - 이미지 피라미드 (4개)
  - 기본 연산 (7개)
  - 산술 연산 (9개)
  - 비교 연산 (6개)
  - 통계 연산 (6개)
  - 행렬 연산 (8개)
  - 고급 필터 (8개)
  - 미분 연산 (3개)
  - 그리기 (7개)
  - 각종 이미지변환 (10개)
  - 모션 분석 및 객체 추적 (8개)

### Phase 5: 교육 기능 추가
- 함수 문법 표시
- 파라미터 설명
- 공식 문서 링크
- 처리 시간 측정

### Phase 6: 최적화 및 버그 수정
- 중복 case문 제거
- 중복 함수 정의 제거
- 메모리 누수 방지
- 에러 처리 강화
- TypeScript 타입 안정성 개선

### Phase 7: 최종 검증
- 전체 함수 테스트
- UI/UX 검증
- 성능 측정
- 문서화

---

## 🔍 코드 통계

### 파일 수
- 총 컴포넌트: 7개 (커스텀 컴포넌트)
- UI 컴포넌트: 40+ (shadcn/ui)
- 유틸리티: 1개
- 데이터: 1개

### 코드 라인 수 (추정)
- opencv-functions.ts: ~4,200 lines
- opencv-processor.ts: ~2,700 lines
- Components: ~1,500 lines
- 총합: ~8,400+ lines

### 구현 범위
- **카테고리**: 22개
- **함수**: 178개
- **파라미터**: 평균 3-5개/함수 (약 650개 이상)
- **문서 링크**: 178개
- **함수 문법**: 178개

---

## ✅ 완성도 체크리스트

### 기능 완성도
- [x] 이미지 업로드 (단일/듀얼)
- [x] 22개 카테고리 구현
- [x] 178개 함수 구현
- [x] 동적 파라미터 입력
- [x] 실시간 처리
- [x] 결과 다운로드
- [x] 처리 시간 측정
- [x] 에러 처리

### UI/UX 완성도
- [x] 반응형 디자인
- [x] 직관적인 레이아웃
- [x] 카테고리별 그룹핑
- [x] 검색 기능
- [x] 로딩 상태 표시
- [x] 에러 메시지 표시

### 교육 기능 완성도
- [x] 함수 설명
- [x] 정확한 문법 표시
- [x] 파라미터 상세 설명
- [x] 공식 문서 링크
- [x] 실시간 피드백

### 코드 품질
- [x] TypeScript 타입 안정성
- [x] 컴포넌트 모듈화
- [x] 메모리 관리
- [x] 에러 처리
- [x] 코드 중복 제거

---

## 🎉 프로젝트 성과

### 정량적 성과
- **178개 OpenCV 함수** 구현 완료
- **22개 카테고리** 체계적 분류
- **650개 이상 파라미터** 동적 UI 제공
- **178개 문서 링크** 교육 자료 제공
- **0개 빌드 에러** 안정적 코드베이스

### 정성적 성과
- 실습 중심의 효과적인 학습 도구
- 직관적이고 사용하기 쉬운 인터페이스
- 체계적인 함수 분류로 학습 경로 제시
- 즉각적인 피드백으로 이해도 향상
- 확장 가능한 아키텍처

### 기술적 성과
- React + TypeScript 기반 안정적 구조
- OpenCV.js 완전 통합
- 메모리 효율적 처리
- 반응형 UI/UX
- shadcn/ui 기반 일관된 디자인

---

## 📖 참고 자료

### OpenCV 문서
- [OpenCV 공식 문서](https://docs.opencv.org/4.x/)
- [OpenCV.js 튜토리얼](https://docs.opencv.org/4.x/d5/d10/tutorial_js_root.html)
- [OpenCV Python 튜토리얼](https://docs.opencv.org/4.x/d6/d00/tutorial_py_root.html)

### 사용된 기술 문서
- [React 공식 문서](https://react.dev/)
- [TypeScript 문서](https://www.typescriptlang.org/)
- [Tailwind CSS v4](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)
- [Vite](https://vitejs.dev/)

---

## 🏆 결론

OpenCV 학습용 테스팅 보드는 학생들이 OpenCV의 178개 함수를 22개 카테고리로 체계적으로 학습할 수 있는 완성도 높은 교육용 도구입니다. 

**핵심 성과**:
- 3단계 워크플로우로 직관적인 사용성 제공
- 실시간 처리와 즉각적인 피드백
- 정확한 문법과 공식 문서 링크로 교육 효과 극대화
- 안정적인 코드베이스와 확장 가능한 아키텍처

이 프로젝트는 이론 중심의 학습을 넘어 실습 기반의 효과적인 OpenCV 학습 경험을 제공하며, 향후 다양한 기능 확장이 가능한 견고한 기반을 갖추고 있습니다.

---

## 📅 업데이트 이력

### 2026-02-13 Update 1
- **추가된 카테고리**: 모션 분석 및 객체 추적 (Motion Analysis and Object Tracking)
- **추가된 함수**: 8개
  - accumulate: 이미지 누적
  - accumulateSquare: 제곱 이미지 누적
  - accumulateProduct: 곱 이미지 누적
  - accumulateWeighted: 가중 누적 (배경 차분)
  - createHanningWindow: 한닝 윈도우 생성
  - phaseCorrelate: 위상 상관
  - meanShift: Mean Shift 추적
  - CamShift: Continuously Adaptive Mean Shift
- **참조 문서**: https://docs.opencv.org/4.12.0/d7/df3/group__imgproc__motion.html
- **총 카테고리**: 22개
- **총 함수**: 178개

---

**문서 작성일**: 2026년 2월 13일  
**최종 업데이트**: 2026년 2월 13일  
**작성자**: Figma Make AI Assistant  
**버전**: 1.0.0
