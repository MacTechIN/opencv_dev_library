# ⚡ GitHub 푸시 빠른 명령어

## 🎯 한 번에 복사해서 실행

```bash
# Git 초기화 및 GitHub 푸시 (한 번에 실행)
git init && \
git add . && \
git commit -m "Initial commit: OpenCV Testing Board with 250 functions and responsive UI" && \
git branch -M main && \
git remote add origin https://github.com/MacTechIN/OpenCVTestingBoard_UI.git && \
git push -u origin main
```

---

## 📝 단계별 명령어

### 1️⃣ Git 초기화
```bash
git init
```

### 2️⃣ 파일 추가
```bash
git add .
```

### 3️⃣ 커밋
```bash
git commit -m "Initial commit: OpenCV Testing Board with 250 functions and responsive UI"
```

### 4️⃣ 브랜치 변경
```bash
git branch -M main
```

### 5️⃣ 원격 저장소 연결
```bash
git remote add origin https://github.com/MacTechIN/OpenCVTestingBoard_UI.git
```

### 6️⃣ 푸시
```bash
git push -u origin main
```

---

## ✅ 확인 명령어

```bash
# Git 상태 확인
git status

# 원격 저장소 확인
git remote -v

# 브랜치 확인
git branch

# 커밋 이력 확인
git log --oneline
```

---

## 🔄 이후 업데이트

```bash
# 빠른 업데이트 (한 번에 실행)
git add . && \
git commit -m "Update: 변경사항 설명" && \
git push origin main
```

---

## 🎉 푸시 성공 후

**GitHub 확인**: https://github.com/MacTechIN/OpenCVTestingBoard_UI

---

**Tip**: Windows 터미널에서 `\` 대신 `^` 사용 가능
```cmd
git init ^
git add . ^
git commit -m "Initial commit" ^
git push origin main
```
