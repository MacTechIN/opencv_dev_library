# 🎯 OpenCV Function Testing Board

<div align="center">

![OpenCV](https://img.shields.io/badge/OpenCV-4.x-blue?logo=opencv)
![React](https://img.shields.io/badge/React-18.3-61dafb?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178c6?logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.0-38bdf8?logo=tailwindcss)
![License](https://img.shields.io/badge/License-Educational-green)

**OpenCV 학습용 테스팅 보드** - 250개 OpenCV 함수를 브라우저에서 학습하고 테스트하는 교육용 웹 애플리케이션

[🚀 빠른 시작](#-빠른-시작) • [📚 문서](#-문서) • [✨ 주요 기능](#-주요-특징) • [🎓 사용 방법](#-사용-방법)

</div>

---

## 📋 개요

OpenCV의 내장 함수들을 **카테고리별로 학습**하고, 각 함수의 **인자들이 어떤 역할**을 하는지 쉽게 이해할 수 있도록 만든 교육용 웹 애플리케이션입니다.

이미지/동영상을 입력하고, 함수를 선택한 후 각 함수마다 필요한 인자를 입력하여 **처리 결과를 실시간으로 확인**하고 저장할 수 있습니다.

---

## ✨ 주요 특징

- 🎯 **250개 OpenCV 함수** 완벽 구현
- 📊 **27개 카테고리**로 체계적 분류
- 🔄 **3단계 워크플로우**: 입력 → 처리 → 출력
- 📖 **한글 인터페이스**와 상세한 파라미터 설명
- 🔗 **OpenCV 공식 문서** 링크 제공
- 💻 **웹 브라우저**에서 즉시 실행
- ⚡ **실시간 결과** 미리보기
- ⏱️ **처리 시간 측정** 및 표시
- 📱 **완전한 반응형 UI** - 모바일, 태블릿, 데스크톱 지원
- 🎨 **OpenCV 공식 로고** 및 전문적인 브랜딩

---

## 🚀 빠른 시작

### 필수 요구사항
- Node.js 18.0.0 이상
- npm 또는 yarn

### 설치 및 실행

```bash
# 1. 저장소 클론
git clone https://github.com/MacTechIN/OpenCVTestingBoard_UI.git
cd OpenCVTestingBoard_UI

# 2. 의존성 설치
npm install

# 3. 개발 서버 실행
npm run dev

# 4. 브라우저에서 열기
# http://localhost:5173
```

### 빌드

```bash
# 프로덕션 빌드
npm run build

# 빌드 결과물 미리보기
npm run preview
```

---

## 📊 전체 통계

| 항목 | 개수 | 설명 |
|------|------|------|
| **전체 함수** | **250개** | OpenCV 주요 함수 구현 |
| **카테고리** | **27개** | 체계적 분류 |
| **Core 모듈** | 31개 | 기본 배열 연산 |
| **Image Processing** | 155개 | 이미지 처리 및 분석 |
| **Camera Calibration & 3D** | 32개 | 3D 재구성 및 캘리브레이션 |
| **High-level GUI** | 21개 | GUI 인터페이스 |
| **Video - Object Tracking** | 11개 | 객체 추적 |

---

## 🎓 구현된 모듈

### 🔷 Core Module (31개 함수)
- **Basic Operations** (기본 연산) - 7개
- **Arithmetic Operations** (산술 연산) - 9개
- **Comparison Operations** (비교 연산) - 6개
- **Statistical Operations** (통계 연산) - 6개
- **Matrix Operations** (행렬 연산) - 3개

### 🔶 Image Processing Module (155개 함수)
- **Color Conversions** (색상 변환) - 14개
- **ColorMaps** (컬러맵) - 22개
- **Basic Filters** (기본 필터) - 8개
- **Advanced Filters** (고급 필터) - 6개
- **Morphological Operations** (형태학 연산) - 10개
- **Edge Detection** (엣지 검출) - 4개
- **Derivatives** (미분 연산) - 3개
- **Thresholding** (임계값 처리) - 9개
- **Geometric Transforms** (기하학 변환) - 12개
- **Image Pyramids** (이미지 피라미드) - 4개
- **Contours** (윤곽선) - 8개
- **Shape Analysis** (형상 분석) - 7개
- **Feature Detection** (특징 검출) - 9개
- **Histograms** (히스토그램) - 6개
- **Drawing Functions** (그리기 함수) - 7개
- **Motion Analysis** (모션 분석) - 17개
- **Miscellaneous** (기타) - 9개

### 📷 Camera Calibration & 3D Reconstruction (32개 함수) ⭐
- **Camera Calibration** - 카메라 캘리브레이션 및 이미지 왜곡 보정
- **Stereo Vision** - 스테레오 비전 및 깊이 맵 생성
- **3D Reconstruction** - 3차원 재구성 및 투영
- **Pose Estimation** - 포즈 추정 및 변환 계산
- **Triangulation** - 삼각 측량 및 3D 포인트 계산
- **Fisheye Camera** - 어안 렌즈 캘리브레이션

### 🖥️ High-level GUI Module (21개 함수)
- **Window Management** (윈도우 관리) - 8개
- **Keyboard Input** (키보드 입력) - 2개
- **Trackbar** (트랙바) - 6개
- **ROI Selection** (ROI 선택) - 2개
- **Mouse Events** (마우스 이벤트) - 2개
- **Image Display** (이미지 표시) - 1개

### 🎯 Video Module - Object Tracking (11개 함수)
- **Tracker Algorithms** (추적 알고리즘) - 8개
  - MIL, KCF, CSRT, Median Flow, MOSSE, Boosting, GOTURN, TLD
- **Background Subtraction** (배경 차분) - 2개
  - MOG2, KNN
- **Multi-Object Tracking** (다중 객체 추적) - 1개

---

## 🎓 사용 방법

### 1️⃣ 이미지 업로드
- **파일 업로드**: 로컬 이미지 파일 선택
- **샘플 이미지**: 기본 제공 샘플 사용
- **듀얼 이미지**: 일부 함수는 2개의 이미지 입력 지원

### 2️⃣ 함수 선택
- **카테고리 탐색**: 27개 카테고리에서 선택
- **검색 기능**: 함수 이름으로 빠른 검색
- **함수 정보**: 설명, 문법, 공식 문서 링크 확인

### 3️⃣ 파라미터 조정
- **슬라이더**: 숫자 파라미터 조정
- **드롭다운**: 옵션 선택
- **실시간 미리보기**: 파라미터 변경 시 즉시 반영

### 4️⃣ 결과 확인 및 저장
- **결과 이미지**: 처리된 이미지 확인
- **처리 시간**: 실행 시간 측정
- **다운로드**: PNG 형식으로 저장
- **추가 처리**: 결과를 입력으로 재사용

---

## 📱 반응형 UI

### 모바일 (< 1024px)
- ✅ 탭 기반 네비게이션 (입력 / 함수 / 출력)
- ✅ 단일 컬럼 레이아웃
- ✅ 터치 최적화 인터페이스

### 태블릿 (1024px ~ 1280px)
- ✅ 3단 레이아웃 (입력 | 함수 | 출력)
- ✅ 중간 크기 폰트 및 패딩

### 데스크톱 (> 1280px)
- ✅ 완전한 3단 레이아웃 (30% | 40% | 30%)
- ✅ 여유로운 패딩 및 큰 폰트

---

## 🔧 기술 스택

### 프론트엔드
- **React 18.3.1** - UI 라이브러리
- **TypeScript** - 타입 안정성
- **Vite 6.3.5** - 빌드 도구

### 스타일링
- **Tailwind CSS v4** - 유틸리티 CSS (완전 반응형)
- **shadcn/ui** - UI 컴포넌트
- **Lucide React** - 아이콘

### OpenCV
- **opencv-ts 1.3.6** - OpenCV.js TypeScript 바인딩
- **OpenCV.js CDN** - 브라우저용 OpenCV

---

## 📁 프로젝트 구조

```
opencv-testing-board/
├── src/
│   ├── app/
│   │   ├── App.tsx                          # 메인 애플리케이션
│   │   ├── components/
│   │   │   ├── ImageUploader.tsx            # 이미지 업로드
│   │   │   ├── FunctionSelector.tsx         # 함수 선택
│   │   │   ├── ParameterInput.tsx           # 파라미터 입력
│   │   │   ├── OutputPanel.tsx              # 결과 출력
│   │   │   ├── UsagePanel.tsx               # 사용법 표시
│   │   │   └── ui/                          # shadcn/ui 컴포넌트
│   │   ├── data/
│   │   │   └── opencv-functions.ts          # 250개 함수 정의
│   │   └── utils/
│   │       └── opencv-processor.ts          # OpenCV 처리 로직
│   └── styles/                               # CSS 파일
├── package.json                              # 의존성
├── vite.config.ts                            # Vite 설정
└── README.md                                 # 이 파일
```

---

## 💡 예제 함수

### 색상 변환
```python
cv.cvtColor(src, cv.COLOR_BGR2GRAY)
cv.applyColorMap(src, cv.COLORMAP_JET)
```

### 필터링
```python
cv.GaussianBlur(src, ksize=(5,5), sigmaX=1.0)
cv.bilateralFilter(src, d=9, sigmaColor=75, sigmaSpace=75)
```

### 엣지 검출
```python
cv.Canny(src, threshold1=100, threshold2=200)
cv.Sobel(src, ddepth=-1, dx=1, dy=0, ksize=3)
```

### 형태학 연산
```python
cv.erode(src, kernel, iterations=1)
cv.morphologyEx(src, cv.MORPH_GRADIENT, kernel)
```

### 3D 재구성
```python
cv.calibrateCamera(objectPoints, imagePoints, imageSize)
cv.stereoCalibrate(objPoints, imgPoints1, imgPoints2)
```

---

## 📚 문서

### 핵심 문서
- **[PROJECT_ARCHIVE_COMPLETE.md](PROJECT_ARCHIVE_COMPLETE.md)** - 완전한 프로젝트 보관 문서 (1,750+ 라인)
- **[CURRENT_STATUS.md](CURRENT_STATUS.md)** - 현재 상태 및 전체 개요
- **[QUICK_START.md](QUICK_START.md)** - 빠른 시작 가이드

### 모듈별 문서
- **[HIGHGUI_FUNCTIONS_ADDED.md](HIGHGUI_FUNCTIONS_ADDED.md)** - High-level GUI 함수 추가 내역
- **[MOTION_ANALYSIS_FUNCTIONS_ADDED.md](MOTION_ANALYSIS_FUNCTIONS_ADDED.md)** - 모션 분석 함수
- **[OBJECT_TRACKING_FUNCTIONS_ADDED.md](OBJECT_TRACKING_FUNCTIONS_ADDED.md)** - 객체 추적 함수

### 개발 문서
- **[ImplementationHistory.md](ImplementationHistory.md)** - 구현 이력
- **[CATEGORY_UPDATE_README.md](CATEGORY_UPDATE_README.md)** - 카테고리 업데이트 가이드
- **[SCRIPT_FEATURES.md](SCRIPT_FEATURES.md)** - 스크립트 기능 상세

---

## 🌟 교육적 가치

### 학생들이 배우는 내용

#### 1. OpenCV 함수 구조
- 함수 이름, 파라미터, 반환값
- 정확한 문법 및 사용법 (Python/C++)

#### 2. 파라미터의 역할
- 각 파라미터가 결과에 미치는 영향
- 실시간 조정으로 최적 값 찾기

#### 3. 이미지 처리 이론
- 색상 공간, 필터링, 형태학, 엣지 검출
- 즉각적인 시각적 피드백

#### 4. 3D 비전 및 캘리브레이션
- 카메라 캘리브레이션 원리
- 스테레오 비전 및 깊이 맵
- 3D 재구성

#### 5. 객체 추적
- 다양한 추적 알고리즘 비교
- 배경 차분 기법
- 실시간 추적 시뮬레이션

---

## 🔄 최근 업데이트

### v2.0.0 (2026-02-14) ⭐ 최신
- ✅ **완전한 반응형 UI** - 모바일/태블릿/데스크톱 지원
- ✅ **OpenCV 공식 로고** 추가 및 브랜딩 업데이트
- ✅ **모바일 탭 네비게이션** (입력/함수/출력)
- ✅ **Camera Calibration & 3D** 모듈 추가 (32개 함수)
- ✅ 총 함수: 218개 → **250개** (+32개)
- ✅ 총 카테고리: 26개 → **27개** (+1개)

### v1.x (2026-02-13)
- ✅ High-level GUI 모듈 (21개 함수)
- ✅ Motion Analysis 확장 (17개 함수)
- ✅ Object Tracking 모듈 (11개 함수)

---

## 🚀 향후 계획

### 새로운 모듈
- [ ] **Feature2D** (SIFT, SURF, ORB, AKAZE 등)
- [ ] **DNN Module** (딥러닝 추론)
- [ ] **Photo Module** (사진 처리 특화)
- [ ] **Video I/O** (비디오 파일 처리)

### 기능 개선
- [ ] **코드 생성** - 함수 호출 코드 자동 생성 (Python/C++/JavaScript)
- [ ] **학습 모드** - 단계별 튜토리얼
- [ ] **비교 모드** - 여러 함수 결과 동시 비교
- [ ] **히스토리** - 처리 이력 저장 및 복원

### 성능 최적화
- [ ] **Web Worker** - 백그라운드 처리
- [ ] **WebAssembly** - 네이티브 수준 성능
- [ ] **캐싱** - 처리 결과 캐싱

---

## 📚 참고 자료

- [OpenCV 공식 문서](https://docs.opencv.org/4.x/)
- [OpenCV Python Tutorials](https://docs.opencv.org/4.x/d6/d00/tutorial_py_root.html)
- [opencv-ts GitHub](https://github.com/opencv/opencv)
- [OpenCV.js 문서](https://docs.opencv.org/4.x/d5/d10/tutorial_js_root.html)

---

## 🤝 기여

교육 목적으로 제작된 오픈소스 프로젝트입니다. 기여를 환영합니다!

### 기여 방법
1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 라이선스

이 프로젝트는 **교육 목적**으로 제작되었습니다.

OpenCV는 Apache 2.0 라이선스를 따릅니다.

---

## 📞 문의

프로젝트에 대한 질문이나 제안사항이 있으시면 GitHub Issues를 이용해주세요.

---

<div align="center">

**OpenCV Function Testing Board** - 250개 함수로 배우는 컴퓨터 비전

Made with ❤️ for Education

**버전**: 2.0.0  
**최종 업데이트**: 2026년 2월 14일  
**함수 개수**: 250개  
**카테고리**: 27개  
**지원 디바이스**: 모바일, 태블릿, 데스크톱

⭐ Star this repository if you find it helpful!

</div>
